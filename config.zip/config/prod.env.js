'use strict'
module.exports = {
    NODE_ENV: '"production"',
    API_HOST: '"http://bromiao.top"',  // 正式环境接口地址
    apis:'"https://c.y.qq.com"',
    Vkey:'"https://u.y.qq.com"'
}
